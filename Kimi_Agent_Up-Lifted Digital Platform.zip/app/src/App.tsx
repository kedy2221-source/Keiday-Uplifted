import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { 
  Home, Briefcase, BookOpen, Heart, TrendingUp, Users, 
  Mail, Phone, MessageCircle, MapPin, ChevronDown, Menu, X,
  ArrowRight, CheckCircle, Star, Building2, GraduationCap,
  PhoneCall, MessageSquare
} from 'lucide-react';
import './App.css';

// ==================== NAVIGATION COMPONENT ====================
function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 w-full z-[100] bg-white/95 backdrop-blur-md shadow-sm">
      <div className="max-w-7xl mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-blue-600 flex items-center justify-center">
              <span className="text-white font-bold text-lg">U</span>
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
              Up-Lifted
            </span>
          </Link>
          
          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-1">
            <Link to="/" className={`nav-link ${isActive('/') ? 'active' : ''}`}>
              Home
            </Link>
            <Link to="/about" className={`nav-link ${isActive('/about') ? 'active' : ''}`}>
              About Us
            </Link>
            
            {/* Services Dropdown */}
            <div className="relative">
              <button 
                className={`nav-link flex items-center gap-1 ${location.pathname.startsWith('/services') ? 'active' : ''}`}
                onMouseEnter={() => setServicesOpen(true)}
                onMouseLeave={() => setServicesOpen(false)}
              >
                Services
                <ChevronDown size={16} className={`transition-transform ${servicesOpen ? 'rotate-180' : ''}`} />
              </button>
              
              {servicesOpen && (
                <div 
                  className="absolute top-full left-0 w-56 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 animate-fade-in"
                  onMouseEnter={() => setServicesOpen(true)}
                  onMouseLeave={() => setServicesOpen(false)}
                >
                  <Link to="/services/housing" className="dropdown-item">
                    <Home size={18} className="text-emerald-500" />
                    Housing
                  </Link>
                  <Link to="/services/employment" className="dropdown-item">
                    <Briefcase size={18} className="text-blue-500" />
                    Employment
                  </Link>
                  <Link to="/services/education" className="dropdown-item">
                    <BookOpen size={18} className="text-purple-500" />
                    Education
                  </Link>
                  <Link to="/services/mental-wellbeing" className="dropdown-item">
                    <Heart size={18} className="text-rose-500" />
                    Mental Well-being
                  </Link>
                  <Link to="/services/career" className="dropdown-item">
                    <TrendingUp size={18} className="text-amber-500" />
                    Career
                  </Link>
                </div>
              )}
            </div>
            
            <Link to="/pathways" className={`nav-link ${isActive('/pathways') ? 'active' : ''}`}>
              Pathways
            </Link>
            <Link to="/community" className={`nav-link ${isActive('/community') ? 'active' : ''}`}>
              Community
            </Link>
            <Link to="/contact" className={`nav-link ${isActive('/contact') ? 'active' : ''}`}>
              Contact
            </Link>
          </div>

          {/* CTA Button */}
          <div className="hidden lg:block">
            <Link to="/booking" className="btn-primary">
              Book Premium
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsOpen(!isOpen)} className="lg:hidden p-2">
            {isOpen ? <X size={24} className="text-gray-700" /> : <Menu size={24} className="text-gray-700" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-white border-t border-gray-100 animate-slide-down">
          <div className="px-4 py-4 space-y-2">
            <Link to="/" className="mobile-nav-link" onClick={() => setIsOpen(false)}>Home</Link>
            <Link to="/about" className="mobile-nav-link" onClick={() => setIsOpen(false)}>About Us</Link>
            <div className="py-2">
              <div className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">Services</div>
              <Link to="/services/housing" className="mobile-nav-link pl-4" onClick={() => setIsOpen(false)}>Housing</Link>
              <Link to="/services/employment" className="mobile-nav-link pl-4" onClick={() => setIsOpen(false)}>Employment</Link>
              <Link to="/services/education" className="mobile-nav-link pl-4" onClick={() => setIsOpen(false)}>Education</Link>
              <Link to="/services/mental-wellbeing" className="mobile-nav-link pl-4" onClick={() => setIsOpen(false)}>Mental Well-being</Link>
              <Link to="/services/career" className="mobile-nav-link pl-4" onClick={() => setIsOpen(false)}>Career</Link>
            </div>
            <Link to="/pathways" className="mobile-nav-link" onClick={() => setIsOpen(false)}>Pathways</Link>
            <Link to="/community" className="mobile-nav-link" onClick={() => setIsOpen(false)}>Community</Link>
            <Link to="/contact" className="mobile-nav-link" onClick={() => setIsOpen(false)}>Contact</Link>
            <Link to="/booking" className="btn-primary w-full text-center mt-4" onClick={() => setIsOpen(false)}>
              Book Premium
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}

// ==================== FOOTER COMPONENT ====================
function Footer() {
  return (
    <footer className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-blue-600 flex items-center justify-center">
                <span className="text-white font-bold text-lg">U</span>
              </div>
              <span className="text-xl font-bold">Up-Lifted</span>
            </div>
            <p className="text-slate-400 leading-relaxed mb-6">
              Empowering newcomers in Canada through integrated housing, employment, and education services.
            </p>
            <div className="flex gap-3">
              <a href="mailto:hello@up-lifted.ca" className="social-icon">
                <Mail size={18} />
              </a>
              <a href="tel:+14379873771" className="social-icon">
                <Phone size={18} />
              </a>
              <a href="https://wa.me/14379873771" className="social-icon">
                <MessageSquare size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><Link to="/about" className="footer-link">About Us</Link></li>
              <li><Link to="/services/housing" className="footer-link">Housing Services</Link></li>
              <li><Link to="/services/employment" className="footer-link">Employment Services</Link></li>
              <li><Link to="/pathways" className="footer-link">Pathways</Link></li>
              <li><Link to="/booking" className="footer-link">Book Premium</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Our Services</h4>
            <ul className="space-y-3">
              <li><Link to="/services/housing" className="footer-link">Housing Support</Link></li>
              <li><Link to="/services/employment" className="footer-link">Job Placement</Link></li>
              <li><Link to="/services/education" className="footer-link">Education Guidance</Link></li>
              <li><Link to="/services/mental-wellbeing" className="footer-link">Mental Well-being</Link></li>
              <li><Link to="/services/career" className="footer-link">Career Development</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Mail size={20} className="text-emerald-400 mt-1" />
                <div>
                  <div className="text-slate-400 text-sm">Email</div>
                  <a href="mailto:hello@up-lifted.ca" className="text-white hover:text-emerald-400 transition-colors">
                    hello@up-lifted.ca
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Phone size={20} className="text-blue-400 mt-1" />
                <div>
                  <div className="text-slate-400 text-sm">Phone</div>
                  <a href="tel:+14379873771" className="text-white hover:text-blue-400 transition-colors">
                    +1 (437) 987-3771
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={20} className="text-purple-400 mt-1" />
                <div>
                  <div className="text-slate-400 text-sm">Location</div>
                  <span className="text-white">Toronto, ON, Canada</span>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-700 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-slate-400 text-sm">
            © 2026 Up-Lifted Newcomer Inc. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link to="/privacy" className="text-slate-400 text-sm hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="text-slate-400 text-sm hover:text-white transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ==================== HOME PAGE ====================
function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-50 via-white to-blue-50" />
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-bl from-emerald-100/30 to-transparent" />
        <div className="absolute bottom-0 left-0 w-1/3 h-1/2 bg-gradient-to-tr from-blue-100/30 to-transparent" />
        
        {/* Decorative Elements */}
        <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-emerald-400/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-4 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium">
                <Star size={16} className="fill-emerald-700" />
                Welcome to Up-Lifted
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
                <span className="text-slate-800">One Path.</span>
                <br />
                <span className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                  Three Pillars.
                </span>
              </h1>
              
              <p className="text-xl text-slate-600 leading-relaxed max-w-xl">
                Housing, education, and employment—connected in one comprehensive plan designed specifically for newcomers to Canada.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Link to="/booking" className="btn-primary text-lg px-8 py-4">
                  Start Your Journey
                  <ArrowRight size={20} />
                </Link>
                <Link to="/about" className="btn-secondary text-lg px-8 py-4">
                  Learn More
                </Link>
              </div>
              
              {/* Stats */}
              <div className="flex gap-8 pt-8 border-t border-slate-200">
                <div>
                  <div className="text-3xl font-bold text-emerald-600">68%</div>
                  <div className="text-slate-500 text-sm">Faster Housing</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600">3×</div>
                  <div className="text-slate-500 text-sm">Interview Confidence</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-purple-600">12mo</div>
                  <div className="text-slate-500 text-sm">Retention Tracked</div>
                </div>
              </div>
            </div>
            
            {/* Hero Image/Illustration */}
            <div className="relative">
              <div className="relative z-10 grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="card-gradient p-6 rounded-3xl">
                    <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center mb-4">
                      <Home className="text-white" size={24} />
                    </div>
                    <h3 className="text-lg font-bold text-slate-800 mb-2">Housing</h3>
                    <p className="text-slate-600 text-sm">Find your perfect home with our rental roadmap</p>
                  </div>
                  <div className="card-gradient p-6 rounded-3xl">
                    <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center mb-4">
                      <BookOpen className="text-white" size={24} />
                    </div>
                    <h3 className="text-lg font-bold text-slate-800 mb-2">Education</h3>
                    <p className="text-slate-600 text-sm">Credential recognition and learning pathways</p>
                  </div>
                </div>
                <div className="space-y-4 pt-8">
                  <div className="card-gradient p-6 rounded-3xl">
                    <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center mb-4">
                      <Briefcase className="text-white" size={24} />
                    </div>
                    <h3 className="text-lg font-bold text-slate-800 mb-2">Employment</h3>
                    <p className="text-slate-600 text-sm">Land the right role with our support</p>
                  </div>
                  <div className="card-gradient p-6 rounded-3xl">
                    <div className="w-12 h-12 bg-rose-500 rounded-xl flex items-center justify-center mb-4">
                      <Heart className="text-white" size={24} />
                    </div>
                    <h3 className="text-lg font-bold text-slate-800 mb-2">Well-being</h3>
                    <p className="text-slate-600 text-sm">Mental health and community support</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-slate-800 mb-6">
              How <span className="text-emerald-600">Up-Lifted</span> Works
            </h2>
            <p className="text-lg text-slate-600">
              A clear plan. Real tools. People who've done it before.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Build Your Profile',
                desc: 'Tell us your goals; we map your first 90 days with personalized recommendations.',
                color: 'emerald',
                icon: <Users size={28} />
              },
              {
                step: '02',
                title: 'Follow Your Roadmap',
                desc: 'Step-by-step tasks, templates, and reminders to keep you on track.',
                color: 'blue',
                icon: <MapPin size={28} />
              },
              {
                step: '03',
                title: 'Track & Succeed',
                desc: 'See progress, get help, hit your milestones, and celebrate success.',
                color: 'purple',
                icon: <CheckCircle size={28} />
              }
            ].map((item) => (
              <div key={item.step} className="feature-card group">
                <div className={`w-16 h-16 rounded-2xl bg-${item.color}-100 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <div className={`text-${item.color}-600`}>{item.icon}</div>
                </div>
                <div className={`text-sm font-bold text-${item.color}-600 mb-3`}>STEP {item.step}</div>
                <h3 className="text-2xl font-bold text-slate-800 mb-4">{item.title}</h3>
                <p className="text-slate-600 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-24 bg-gradient-to-br from-slate-50 to-emerald-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-slate-800 mb-6">
              Our <span className="text-blue-600">Services</span>
            </h2>
            <p className="text-lg text-slate-600">
              Comprehensive support for every step of your settlement journey.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: 'Housing', desc: 'Rental roadmap, document prep, and landlord connections.', icon: <Home size={24} />, color: 'emerald', link: '/services/housing' },
              { title: 'Employment', desc: 'Resume support, interview practice, and job matching.', icon: <Briefcase size={24} />, color: 'blue', link: '/services/employment' },
              { title: 'Education', desc: 'Credential recognition and learning pathways.', icon: <BookOpen size={24} />, color: 'purple', link: '/services/education' },
              { title: 'Mental Well-being', desc: 'Support services for your mental health journey.', icon: <Heart size={24} />, color: 'rose', link: '/services/mental-wellbeing' },
              { title: 'Career', desc: 'Long-term career planning and advancement.', icon: <TrendingUp size={24} />, color: 'amber', link: '/services/career' },
              { title: 'Community', desc: 'Connect with mentors, peers, and employers.', icon: <Users size={24} />, color: 'teal', link: '/community' },
            ].map((service) => (
              <Link key={service.title} to={service.link} className={`service-card border-${service.color}-200 hover:border-${service.color}-400`}>
                <div className={`w-14 h-14 rounded-xl bg-${service.color}-100 flex items-center justify-center mb-4`}>
                  <div className={`text-${service.color}-600`}>{service.icon}</div>
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-2">{service.title}</h3>
                <p className="text-slate-600 text-sm leading-relaxed">{service.desc}</p>
                <div className={`mt-4 flex items-center gap-2 text-${service.color}-600 font-medium text-sm`}>
                  Learn more <ArrowRight size={16} />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-emerald-600 to-blue-600">
        <div className="max-w-4xl mx-auto px-4 lg:px-8 text-center">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of newcomers who have found their path to success in Canada with Up-Lifted.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/booking" className="bg-white text-emerald-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-colors inline-flex items-center gap-2">
              Book Premium Service
              <ArrowRight size={20} />
            </Link>
            <Link to="/contact" className="border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white/10 transition-colors">
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

// ==================== ABOUT US PAGE ====================
function AboutPage() {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-br from-emerald-50 via-white to-blue-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium mb-6">
              <Users size={16} />
              About Up-Lifted
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold text-slate-800 mb-8">
              Building Bridges for <span className="text-emerald-600">Newcomers</span>
            </h1>
          </div>
        </div>
      </section>

      {/* Founders Story */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-slate-800 mb-8">
                Our <span className="text-blue-600">Story</span>
              </h2>
              <div className="prose prose-lg text-slate-600 leading-relaxed space-y-6">
                <p className="text-xl">
                  <strong className="text-slate-800">Up-Lifted is a social enterprise founded by Keiday Ali and Łukasz Niparko</strong> to fill a critical gap in newcomer settlement services by offering information, housing, education, and job opportunities all at once.
                </p>
                <p>
                  The model leverages the interdependence of stable housing and meaningful employment to enhance integration outcomes and mental well-being. We believe that when newcomers have a safe place to call home and meaningful work to sustain themselves, everything else falls into place.
                </p>
                <p>
                  Starting in Toronto, the business will scale to Montreal and British Columbia, three of Canada's most newcomer-friendly provinces. Our vision is to create a nationwide network of support that follows newcomers from their first day to their full integration into Canadian society.
                </p>
              </div>
              
              {/* Founders */}
              <div className="mt-12 grid sm:grid-cols-2 gap-6">
                <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 p-6 rounded-2xl">
                  <div className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mb-4">
                    KA
                  </div>
                  <h4 className="text-lg font-bold text-slate-800">Keiday Ali</h4>
                  <p className="text-emerald-600 font-medium">Co-Founder</p>
                  <a href="mailto:kedy2221@gmail.com" className="text-slate-500 text-sm hover:text-emerald-600 transition-colors">
                    kedy2221@gmail.com
                  </a>
                </div>
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-2xl">
                  <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mb-4">
                    ŁN
                  </div>
                  <h4 className="text-lg font-bold text-slate-800">Łukasz Niparko</h4>
                  <p className="text-blue-600 font-medium">Co-Founder</p>
                  <a href="mailto:lukaszniparko@gmail.com" className="text-slate-500 text-sm hover:text-blue-600 transition-colors">
                    lukaszniparko@gmail.com
                  </a>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-200 to-blue-200 rounded-3xl transform rotate-3" />
              <div className="relative bg-white p-8 rounded-3xl shadow-xl">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center p-6 bg-emerald-50 rounded-2xl">
                    <div className="text-4xl font-bold text-emerald-600 mb-2">2025</div>
                    <div className="text-slate-600">Founded</div>
                  </div>
                  <div className="text-center p-6 bg-blue-50 rounded-2xl">
                    <div className="text-4xl font-bold text-blue-600 mb-2">3</div>
                    <div className="text-slate-600">Provinces</div>
                  </div>
                  <div className="text-center p-6 bg-purple-50 rounded-2xl">
                    <div className="text-4xl font-bold text-purple-600 mb-2">5</div>
                    <div className="text-slate-600">Core Services</div>
                  </div>
                  <div className="text-center p-6 bg-rose-50 rounded-2xl">
                    <div className="text-4xl font-bold text-rose-600 mb-2">∞</div>
                    <div className="text-slate-600">Possibilities</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-gradient-to-br from-slate-50 to-emerald-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Mission */}
            <div className="bg-white p-10 rounded-3xl shadow-lg">
              <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mb-6">
                <Target className="text-emerald-600" size={32} />
              </div>
              <h3 className="text-3xl font-bold text-slate-800 mb-6">Mission Statement</h3>
              <p className="text-lg text-slate-600 leading-relaxed">
                To empower newcomers in Canada by providing integrated access to housing and employment services, fostering self-reliance, mental well-being, and economic inclusion.
              </p>
            </div>
            
            {/* Vision */}
            <div className="bg-white p-10 rounded-3xl shadow-lg">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                <Eye className="text-blue-600" size={32} />
              </div>
              <h3 className="text-3xl font-bold text-slate-800 mb-6">Vision Statement</h3>
              <p className="text-lg text-slate-600 leading-relaxed">
                A Canada where every newcomer has the opportunity to thrive through dignified housing, fair employment, and holistic community support.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold text-slate-800 mb-6">
              Our <span className="text-purple-600">Core Values</span>
            </h2>
            <p className="text-lg text-slate-600">
              The principles that guide everything we do at Up-Lifted.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { 
                title: 'Equity', 
                desc: 'Equal access to opportunity and support for all newcomers, regardless of background.',
                icon: <ScaleIcon />,
                color: 'emerald'
              },
              { 
                title: 'Empowerment', 
                desc: 'Fostering self-reliance and personal agency in every individual we serve.',
                icon: <SparklesIcon />,
                color: 'blue'
              },
              { 
                title: 'Innovation', 
                desc: 'Designing flexible, community-responsive solutions that evolve with needs.',
                icon: <LightbulbIcon />,
                color: 'purple'
              },
              { 
                title: 'Collaboration', 
                desc: 'Partnering with government, employers, landlords, and community organizations.',
                icon: <HandshakeIcon />,
                color: 'rose'
              },
            ].map((value) => (
              <div key={value.title} className="value-card">
                <div className={`w-14 h-14 bg-${value.color}-100 rounded-xl flex items-center justify-center mb-6`}>
                  <div className={`text-${value.color}-600`}>{value.icon}</div>
                </div>
                <h4 className="text-xl font-bold text-slate-800 mb-3">{value.title}</h4>
                <p className="text-slate-600 leading-relaxed">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Expansion Timeline */}
      <section className="py-20 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold mb-6">
              Our <span className="text-emerald-400">Expansion</span> Plan
            </h2>
            <p className="text-lg text-slate-300">
              Growing to serve newcomers across Canada's most welcoming provinces.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { city: 'Toronto', status: 'Active Now', year: '2025', color: 'emerald', desc: 'Headquarters and first operations' },
              { city: 'Montreal', status: 'Coming Soon', year: '2026', color: 'blue', desc: 'French-language services and Quebec pathways' },
              { city: 'British Columbia', status: 'Coming Soon', year: '2027', color: 'purple', desc: 'West coast expansion and tech sector focus' },
            ].map((location) => (
              <div key={location.city} className="bg-white/10 backdrop-blur-sm p-8 rounded-3xl border border-white/10">
                <div className={`inline-flex items-center gap-2 px-3 py-1 bg-${location.color}-500/20 text-${location.color}-400 rounded-full text-sm font-medium mb-4`}>
                  <MapPin size={14} />
                  {location.status}
                </div>
                <h3 className="text-2xl font-bold mb-2">{location.city}</h3>
                <div className={`text-${location.color}-400 font-semibold mb-4`}>{location.year}</div>
                <p className="text-slate-400">{location.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

// ==================== SERVICE PAGES ====================
function HousingServicePage() {
  return (
    <ServicePageTemplate
      title="Housing Services"
      subtitle="Find Your Perfect Home"
      description="Our comprehensive housing support helps newcomers navigate the Canadian rental market with confidence. From document preparation to landlord connections, we're with you every step of the way."
      icon={<Home size={48} />}
      color="emerald"
      features={[
        { title: 'Rental Roadmap', desc: 'Step-by-step guidance through the entire rental process.' },
        { title: 'Document Prep', desc: 'Help preparing applications, references, and credit checks.' },
        { title: 'Budget Planning', desc: 'Tools to understand costs and plan your housing budget.' },
        { title: 'Landlord Network', desc: 'Connections with welcoming landlords who understand newcomer needs.' },
        { title: 'Lease Review', desc: 'Expert review of rental agreements before you sign.' },
        { title: 'Move-in Support', desc: 'Checklists and resources for a smooth transition.' },
      ]}
    />
  );
}

function EmploymentServicePage() {
  return (
    <ServicePageTemplate
      title="Employment Services"
      subtitle="Land the Right Role"
      description="From resume building to interview preparation, our employment services are designed to help you secure meaningful work that matches your skills and experience."
      icon={<Briefcase size={48} />}
      color="blue"
      features={[
        { title: 'Resume Building', desc: 'Canadian-style resumes tailored to your industry.' },
        { title: 'Interview Practice', desc: 'Mock interviews with feedback and coaching.' },
        { title: 'Job Matching', desc: 'Connections with employers seeking your skills.' },
        { title: 'Skills Assessment', desc: 'Identify transferable skills and gaps to address.' },
        { title: 'Network Building', desc: 'Access to professional networks and mentorship.' },
        { title: 'Workplace Culture', desc: 'Understanding Canadian workplace norms and expectations.' },
      ]}
    />
  );
}

function EducationServicePage() {
  return (
    <ServicePageTemplate
      title="Education Services"
      subtitle="Recognize Your Credentials"
      description="Navigate the credential recognition process and access educational pathways that help you continue your professional journey in Canada."
      icon={<BookOpen size={48} />}
      color="purple"
      features={[
        { title: 'Credential Assessment', desc: 'Guidance on getting your qualifications recognized.' },
        { title: 'Bridging Programs', desc: 'Information on programs to fill knowledge gaps.' },
        { title: 'Licensing Support', desc: 'Help with professional licensing requirements.' },
        { title: 'Course Recommendations', desc: 'Suggested courses to enhance your profile.' },
        { title: 'Academic Pathways', desc: 'Options for further education in Canada.' },
        { title: 'Language Training', desc: 'Resources to improve English or French proficiency.' },
      ]}
    />
  );
}

function MentalWellbeingServicePage() {
  return (
    <ServicePageTemplate
      title="Mental Well-being"
      subtitle="Support for Your Journey"
      description="Settlement can be stressful. Our mental well-being services provide the support you need to maintain balance and thrive in your new home."
      icon={<Heart size={48} />}
      color="rose"
      features={[
        { title: 'Counseling Services', desc: 'Access to culturally sensitive mental health support.' },
        { title: 'Support Groups', desc: 'Connect with others going through similar experiences.' },
        { title: 'Stress Management', desc: 'Tools and techniques for managing settlement stress.' },
        { title: 'Community Connection', desc: 'Build social networks and combat isolation.' },
        { title: 'Crisis Support', desc: 'Resources for urgent mental health needs.' },
        { title: 'Wellness Workshops', desc: 'Regular sessions on mental health topics.' },
      ]}
    />
  );
}

function CareerServicePage() {
  return (
    <ServicePageTemplate
      title="Career Development"
      subtitle="Plan Your Future"
      description="Long-term career planning and advancement support to help you achieve your professional goals in Canada."
      icon={<TrendingUp size={48} />}
      color="amber"
      features={[
        { title: 'Career Planning', desc: 'Map out your long-term professional goals.' },
        { title: 'Skill Development', desc: 'Identify and acquire in-demand skills.' },
        { title: 'Mentorship', desc: 'Connect with professionals in your field.' },
        { title: 'Leadership Training', desc: 'Programs to develop management capabilities.' },
        { title: 'Industry Insights', desc: 'Stay informed about trends in your sector.' },
        { title: 'Advancement Support', desc: 'Strategies for moving up in your career.' },
      ]}
    />
  );
}

// Service Page Template
function ServicePageTemplate({ title, subtitle, description, icon, color, features }: {
  title: string;
  subtitle: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  features: { title: string; desc: string }[];
}) {
  const colorClasses: Record<string, { bg: string; text: string; light: string; border: string }> = {
    emerald: { bg: 'bg-emerald-500', text: 'text-emerald-600', light: 'bg-emerald-50', border: 'border-emerald-200' },
    blue: { bg: 'bg-blue-500', text: 'text-blue-600', light: 'bg-blue-50', border: 'border-blue-200' },
    purple: { bg: 'bg-purple-500', text: 'text-purple-600', light: 'bg-purple-50', border: 'border-purple-200' },
    rose: { bg: 'bg-rose-500', text: 'text-rose-600', light: 'bg-rose-50', border: 'border-rose-200' },
    amber: { bg: 'bg-amber-500', text: 'text-amber-600', light: 'bg-amber-50', border: 'border-amber-200' },
  };
  
  const c = colorClasses[color];
  
  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className={`py-20 ${c.light}`}>
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <div className={`inline-flex items-center gap-2 px-4 py-2 ${c.bg} text-white rounded-full text-sm font-medium mb-6`}>
              {icon}
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold text-slate-800 mb-4">
              {title}
            </h1>
            <p className={`text-2xl ${c.text} font-semibold mb-6`}>{subtitle}</p>
            <p className="text-xl text-slate-600 leading-relaxed">
              {description}
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold text-slate-800 mb-6">
              What We <span className={c.text}>Offer</span>
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, i) => (
              <div key={i} className={`p-8 rounded-3xl border ${c.border} hover:shadow-lg transition-shadow`}>
                <div className={`w-12 h-12 ${c.bg} rounded-xl flex items-center justify-center text-white font-bold mb-4`}>
                  {i + 1}
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-3">{feature.title}</h3>
                <p className="text-slate-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className={`py-20 ${c.bg}`}>
        <div className="max-w-4xl mx-auto px-4 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Book a premium consultation and let us help you on your journey.
          </p>
          <Link to="/booking" className="bg-white text-slate-800 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-colors inline-flex items-center gap-2">
            Book Premium Service
            <ArrowRight size={20} />
          </Link>
        </div>
      </section>
    </div>
  );
}

// ==================== PATHWAYS PAGE ====================
function PathwaysPage() {
  return (
    <div className="min-h-screen pt-20">
      <section className="py-20 bg-gradient-to-br from-emerald-50 via-white to-blue-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl lg:text-6xl font-bold text-slate-800 mb-6">
              Your <span className="text-emerald-600">Pathway</span> to Success
            </h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              Choose your journey. Each pathway is designed to guide you through the key steps of settling in Canada.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="space-y-16">
            {/* Housing Pathway */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="order-2 lg:order-1">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium mb-4">
                  <Home size={16} />
                  Pathway 01
                </div>
                <h2 className="text-4xl font-bold text-slate-800 mb-6">Housing Pathway</h2>
                <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                  From understanding the rental market to signing your lease, our housing pathway guides you through every step of finding your home in Canada.
                </p>
                <ul className="space-y-4">
                  {['Understand the rental market', 'Prepare your documents', 'Create a budget plan', 'Apply with confidence', 'Review your lease', 'Move in successfully'].map((step, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle size={20} className="text-emerald-500" />
                      <span className="text-slate-700">{step}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/services/housing" className="btn-primary mt-8 inline-flex">
                  Explore Housing Pathway
                  <ArrowRight size={18} />
                </Link>
              </div>
              <div className="order-1 lg:order-2">
                <div className="bg-gradient-to-br from-emerald-100 to-emerald-200 p-8 rounded-3xl">
                  <div className="bg-white p-6 rounded-2xl shadow-lg">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center">
                        <Home className="text-white" size={24} />
                      </div>
                      <div>
                        <div className="font-bold text-slate-800">Housing Progress</div>
                        <div className="text-emerald-600 text-sm">6 steps to complete</div>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '0%' }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Employment Pathway */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="bg-gradient-to-br from-blue-100 to-blue-200 p-8 rounded-3xl">
                  <div className="bg-white p-6 rounded-2xl shadow-lg">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                        <Briefcase className="text-white" size={24} />
                      </div>
                      <div>
                        <div className="font-bold text-slate-800">Employment Progress</div>
                        <div className="text-blue-600 text-sm">6 steps to complete</div>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-500 h-2 rounded-full" style={{ width: '0%' }} />
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4">
                  <Briefcase size={16} />
                  Pathway 02
                </div>
                <h2 className="text-4xl font-bold text-slate-800 mb-6">Employment Pathway</h2>
                <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                  Build your Canadian career with our comprehensive employment support, from resume building to landing your dream job.
                </p>
                <ul className="space-y-4">
                  {['Assess your skills', 'Build your resume', 'Prepare for interviews', 'Connect with employers', 'Apply for positions', 'Start your new role'].map((step, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle size={20} className="text-blue-500" />
                      <span className="text-slate-700">{step}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/services/employment" className="btn-primary mt-8 inline-flex bg-blue-600 hover:bg-blue-700">
                  Explore Employment Pathway
                  <ArrowRight size={18} />
                </Link>
              </div>
            </div>

            {/* Education Pathway */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="order-2 lg:order-1">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-medium mb-4">
                  <BookOpen size={16} />
                  Pathway 03
                </div>
                <h2 className="text-4xl font-bold text-slate-800 mb-6">Education Pathway</h2>
                <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                  Get your credentials recognized and access educational opportunities that help you advance your career in Canada.
                </p>
                <ul className="space-y-4">
                  {['Assess your credentials', 'Start recognition process', 'Explore bridging programs', 'Meet licensing requirements', 'Enhance your skills', 'Achieve your goals'].map((step, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle size={20} className="text-purple-500" />
                      <span className="text-slate-700">{step}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/services/education" className="btn-primary mt-8 inline-flex bg-purple-600 hover:bg-purple-700">
                  Explore Education Pathway
                  <ArrowRight size={18} />
                </Link>
              </div>
              <div className="order-1 lg:order-2">
                <div className="bg-gradient-to-br from-purple-100 to-purple-200 p-8 rounded-3xl">
                  <div className="bg-white p-6 rounded-2xl shadow-lg">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center">
                        <BookOpen className="text-white" size={24} />
                      </div>
                      <div>
                        <div className="font-bold text-slate-800">Education Progress</div>
                        <div className="text-purple-600 text-sm">6 steps to complete</div>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-purple-500 h-2 rounded-full" style={{ width: '0%' }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

// ==================== COMMUNITY PAGE ====================
function CommunityPage() {
  return (
    <div className="min-h-screen pt-20">
      <section className="py-20 bg-gradient-to-br from-teal-50 via-white to-emerald-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl lg:text-6xl font-bold text-slate-800 mb-6">
              You're <span className="text-teal-600">Not Alone</span>
            </h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              Connect with mentors, peers, employers, and landlords who want to help you succeed.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: 'Mentorship', desc: 'Connect with experienced professionals who can guide your journey.', icon: <Users size={32} />, color: 'teal' },
              { title: 'Peer Groups', desc: 'Join groups of newcomers sharing similar experiences.', icon: <MessageCircle size={32} />, color: 'emerald' },
              { title: 'Employer Network', desc: 'Access employers actively seeking newcomer talent.', icon: <Building2 size={32} />, color: 'blue' },
              { title: 'Landlord Partners', desc: 'Connect with welcoming landlords who understand newcomer needs.', icon: <Home size={32} />, color: 'purple' },
            ].map((item) => (
              <div key={item.title} className="text-center p-8 rounded-3xl bg-slate-50 hover:bg-white hover:shadow-xl transition-all">
                <div className={`w-16 h-16 bg-${item.color}-100 rounded-2xl flex items-center justify-center mx-auto mb-6`}>
                  <div className={`text-${item.color}-600`}>{item.icon}</div>
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-3">{item.title}</h3>
                <p className="text-slate-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold mb-6">
              Join Our <span className="text-teal-400">Community</span>
            </h2>
            <p className="text-lg text-slate-300">
              Mentor matches available within 48 hours. Start building your network today.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white/10 backdrop-blur-sm p-8 rounded-3xl border border-white/10 text-center">
              <div className="text-5xl font-bold text-teal-400 mb-2">500+</div>
              <div className="text-slate-300">Active Mentors</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-8 rounded-3xl border border-white/10 text-center">
              <div className="text-5xl font-bold text-emerald-400 mb-2">2,000+</div>
              <div className="text-slate-300">Community Members</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-8 rounded-3xl border border-white/10 text-center">
              <div className="text-5xl font-bold text-blue-400 mb-2">150+</div>
              <div className="text-slate-300">Partner Employers</div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Link to="/contact" className="bg-teal-500 text-white px-8 py-4 rounded-xl font-semibold hover:bg-teal-600 transition-colors inline-flex items-center gap-2">
              Join the Community
              <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

// ==================== CONTACT PAGE ====================
function ContactPage() {
  return (
    <div className="min-h-screen pt-20">
      <section className="py-20 bg-gradient-to-br from-blue-50 via-white to-emerald-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl lg:text-6xl font-bold text-slate-800 mb-6">
              Let's <span className="text-blue-600">Connect</span>
            </h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              We're here to help. Reach out through any of these channels.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {/* Email */}
            <a href="mailto:hello@up-lifted.ca" className="contact-card group">
              <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-emerald-500 transition-colors">
                <Mail className="text-emerald-600 group-hover:text-white transition-colors" size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">Email Us</h3>
              <p className="text-slate-600 mb-4">Send us an email anytime</p>
              <span className="text-emerald-600 font-medium">hello@up-lifted.ca</span>
            </a>

            {/* Phone */}
            <a href="tel:+14379873771" className="contact-card group">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-500 transition-colors">
                <PhoneCall className="text-blue-600 group-hover:text-white transition-colors" size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">Call Us</h3>
              <p className="text-slate-600 mb-4">Speak with our team</p>
              <span className="text-blue-600 font-medium">+1 (437) 987-3771</span>
            </a>

            {/* WhatsApp */}
            <a href="https://wa.me/14379873771" target="_blank" rel="noopener noreferrer" className="contact-card group">
              <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-green-500 transition-colors">
                <MessageSquare className="text-green-600 group-hover:text-white transition-colors" size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">WhatsApp</h3>
              <p className="text-slate-600 mb-4">Message us on WhatsApp</p>
              <span className="text-green-600 font-medium">+1 (437) 987-3771</span>
            </a>

            {/* Text */}
            <a href="sms:+14379873771" className="contact-card group">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-purple-500 transition-colors">
                <MessageCircle className="text-purple-600 group-hover:text-white transition-colors" size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">Text Us</h3>
              <p className="text-slate-600 mb-4">Send us a text message</p>
              <span className="text-purple-600 font-medium">+1 (437) 987-3771</span>
            </a>
          </div>

          {/* Contact Form */}
          <div className="max-w-2xl mx-auto">
            <div className="bg-slate-50 p-8 lg:p-12 rounded-3xl">
              <h2 className="text-3xl font-bold text-slate-800 mb-2 text-center">Send Us a Message</h2>
              <p className="text-slate-600 text-center mb-8">Fill out the form below and we'll get back to you within 24 hours.</p>
              
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">First Name</label>
                    <input type="text" className="form-input" placeholder="Your first name" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Last Name</label>
                    <input type="text" className="form-input" placeholder="Your last name" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                  <input type="email" className="form-input" placeholder="your@email.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Subject</label>
                  <select className="form-input">
                    <option>Select a subject</option>
                    <option>Housing Support</option>
                    <option>Employment Help</option>
                    <option>Education Guidance</option>
                    <option>General Inquiry</option>
                    <option>Partnership</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Message</label>
                  <textarea rows={5} className="form-input resize-none" placeholder="How can we help you?"></textarea>
                </div>
                <button type="submit" className="btn-primary w-full justify-center">
                  Send Message
                  <ArrowRight size={18} />
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

// ==================== BOOKING PAGE ====================
function BookingPage() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const plans = [
    {
      id: 'newcomer',
      title: 'Newcomer Premium',
      subtitle: 'For Individuals',
      price: '$49',
      period: '/month',
      description: 'Complete support for your settlement journey',
      icon: <Users size={32} />,
      color: 'emerald',
      features: [
        'Personalized settlement roadmap',
        'Housing search assistance',
        'Resume & cover letter review',
        'Interview coaching (2 sessions)',
        'Credential assessment guidance',
        'Monthly mentor check-ins',
        'Priority support',
        'Document templates library',
      ]
    },
    {
      id: 'landlord',
      title: 'Landlord Partner',
      subtitle: 'For Property Owners',
      price: '$99',
      period: '/month',
      description: 'Connect with quality newcomer tenants',
      icon: <Building2 size={32} />,
      color: 'blue',
      features: [
        'Tenant pre-screening service',
        'Newcomer-ready property listing',
        'Document verification support',
        'Cultural orientation resources',
        'Dedicated account manager',
        'Priority tenant matching',
        'Rental guarantee options',
        '24/7 landlord support line',
      ]
    },
    {
      id: 'employer',
      title: 'Employer Partner',
      subtitle: 'For Businesses',
      price: '$199',
      period: '/month',
      description: 'Access skilled newcomer talent',
      icon: <Briefcase size={32} />,
      color: 'purple',
      features: [
        'Curated candidate pool access',
        'Skills assessment reports',
        'Cultural fit evaluation',
        'Onboarding support',
        'Diversity & inclusion consulting',
        'Job posting promotion',
        'Interview scheduling',
        'Retention tracking',
      ]
    },
    {
      id: 'education',
      title: 'Education Pathway',
      subtitle: 'For Institutions',
      price: '$149',
      period: '/month',
      description: 'Support international students & professionals',
      icon: <GraduationCap size={32} />,
      color: 'amber',
      features: [
        'Student onboarding program',
        'Credential evaluation service',
        'Academic pathway planning',
        'Language support resources',
        'Career transition guidance',
        'Alumni network access',
        'Partnership branding',
        'Impact reporting dashboard',
      ]
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      <section className="py-20 bg-gradient-to-br from-emerald-50 via-white to-blue-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl lg:text-6xl font-bold text-slate-800 mb-6">
              Book <span className="text-emerald-600">Premium</span> Services
            </h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              Choose the plan that fits your needs. All plans include dedicated support and access to our full platform.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            {plans.map((plan) => (
              <div 
                key={plan.id}
                className={`booking-card ${selectedPlan === plan.id ? 'ring-2 ring-emerald-500' : ''}`}
                onClick={() => setSelectedPlan(plan.id)}
              >
                <div className="flex items-start justify-between mb-6">
                  <div className={`w-14 h-14 bg-${plan.color}-100 rounded-xl flex items-center justify-center`}>
                    <div className={`text-${plan.color}-600`}>{plan.icon}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-slate-800">{plan.price}</div>
                    <div className="text-slate-500 text-sm">{plan.period}</div>
                  </div>
                </div>
                
                <div className="mb-2 text-sm font-medium text-slate-500 uppercase tracking-wider">{plan.subtitle}</div>
                <h3 className="text-2xl font-bold text-slate-800 mb-3">{plan.title}</h3>
                <p className="text-slate-600 mb-6">{plan.description}</p>
                
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <CheckCircle size={18} className="text-emerald-500 flex-shrink-0" />
                      <span className="text-slate-700 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button className={`w-full py-4 rounded-xl font-semibold transition-colors ${
                  selectedPlan === plan.id 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}>
                  {selectedPlan === plan.id ? 'Selected' : 'Select Plan'}
                </button>
              </div>
            ))}
          </div>

          {selectedPlan && (
            <div className="mt-12 max-w-2xl mx-auto">
              <div className="bg-emerald-50 p-8 rounded-3xl border border-emerald-200">
                <h3 className="text-2xl font-bold text-slate-800 mb-4">Complete Your Booking</h3>
                <p className="text-slate-600 mb-6">
                  You've selected the <strong>{plans.find(p => p.id === selectedPlan)?.title}</strong> plan. Fill in your details to get started.
                </p>
                <form className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <input type="text" className="form-input" placeholder="Full Name" />
                    <input type="email" className="form-input" placeholder="Email Address" />
                  </div>
                  <input type="tel" className="form-input" placeholder="Phone Number" />
                  <button type="submit" className="btn-primary w-full justify-center">
                    Complete Booking
                    <ArrowRight size={18} />
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

// ==================== ICON COMPONENTS ====================
function Target({ className, size }: { className?: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="6" />
      <circle cx="12" cy="12" r="2" />
    </svg>
  );
}

function Eye({ className, size }: { className?: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

function ScaleIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
      <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
      <path d="M7 21h10" />
      <path d="M12 3v18" />
      <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2" />
    </svg>
  );
}

function SparklesIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
      <path d="M5 3v4" />
      <path d="M19 17v4" />
      <path d="M3 5h4" />
      <path d="M17 19h4" />
    </svg>
  );
}

function LightbulbIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5" />
      <path d="M9 18h6" />
      <path d="M10 22h4" />
    </svg>
  );
}

function HandshakeIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m11 17 2 2a1 1 0 1 0 3-3" />
      <path d="m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4" />
      <path d="m21 3 1 11h-2" />
      <path d="M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3" />
      <path d="M3 4h8" />
    </svg>
  );
}

// ==================== MAIN APP ====================
function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/services/housing" element={<HousingServicePage />} />
        <Route path="/services/employment" element={<EmploymentServicePage />} />
        <Route path="/services/education" element={<EducationServicePage />} />
        <Route path="/services/mental-wellbeing" element={<MentalWellbeingServicePage />} />
        <Route path="/services/career" element={<CareerServicePage />} />
        <Route path="/pathways" element={<PathwaysPage />} />
        <Route path="/community" element={<CommunityPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/booking" element={<BookingPage />} />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
